
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `active__school_year_and_sems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active__school_year_and_sems` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `active_SY_id` bigint unsigned NOT NULL,
  `active_sem_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `active__school_year_and_sems_active_sy_id_foreign` (`active_SY_id`),
  KEY `active__school_year_and_sems_active_sem_id_foreign` (`active_sem_id`),
  CONSTRAINT `active__school_year_and_sems_active_sem_id_foreign` FOREIGN KEY (`active_sem_id`) REFERENCES `sems` (`id`),
  CONSTRAINT `active__school_year_and_sems_active_sy_id_foreign` FOREIGN KEY (`active_SY_id`) REFERENCES `school_years` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `active__school_year_and_sems` WRITE;
/*!40000 ALTER TABLE `active__school_year_and_sems` DISABLE KEYS */;
INSERT INTO `active__school_year_and_sems` VALUES (1,1,2,NULL,'2024-01-10 19:53:29');
/*!40000 ALTER TABLE `active__school_year_and_sems` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_user_id_foreign` (`user_id`),
  CONSTRAINT `activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (1,1,'Teacher Management','Added Teacher Alryl Kyle Mondez','2023-12-15 15:14:27','2023-12-15 15:14:27'),(2,1,'Teacher Management','Deleted Teacher Alryl Kyle Mondez','2023-12-15 15:14:52','2023-12-15 15:14:52'),(3,1,'Teacher Management','Added Teacher Ramil Kaharian','2023-12-15 15:16:35','2023-12-15 15:16:35'),(4,1,'Teacher Management','Added Teacher Alexa Smith','2023-12-15 15:17:25','2023-12-15 15:17:25'),(5,1,'Teacher Management','Added Teacher May Abanilla','2023-12-15 15:19:49','2023-12-15 15:19:49'),(6,1,'Schedule Management','Added a new schedule','2023-12-15 15:51:44','2023-12-15 15:51:44'),(7,1,'Enrolled Student`s Subject','Enrolled Student Alexander L Corales','2023-12-15 16:38:15','2023-12-15 16:38:15'),(8,1,'Schedule Management','Added a new schedule','2023-12-15 20:46:47','2023-12-15 20:46:47'),(9,1,'Schedule Management','Added a new schedule','2024-01-03 23:39:52','2024-01-03 23:39:52'),(10,1,'Enrolled Student`s Subject','Enrolled Student Gian L Abella','2024-01-03 23:42:02','2024-01-03 23:42:02'),(11,1,'Teacher Management','Added Teacher Raden Arellano','2024-01-04 00:22:03','2024-01-04 00:22:03'),(12,1,'Schedule Management','Added a new schedule','2024-01-07 19:02:05','2024-01-07 19:02:05'),(13,1,'Enrolled Student`s Subject','Enrolled Student Jerome C Lamoca','2024-01-08 21:50:31','2024-01-08 21:50:31'),(14,1,'User Management','Updated user Registrar password','2024-01-09 01:37:17','2024-01-09 01:37:17'),(15,3,'Enrolled Student`s Subject','Enrolled Student Aljohn L Cagas','2024-01-09 01:42:13','2024-01-09 01:42:13'),(16,1,'User Management','Updated user Accounting password','2024-01-09 01:57:11','2024-01-09 01:57:11'),(17,1,'Enrolled Student`s Subject','Enrolled Student Jessu L Credo','2024-01-09 22:26:14','2024-01-09 22:26:14'),(18,3,'Enrolled Student`s Subject','Enrolled Student Ian L Geanga','2024-01-10 04:41:30','2024-01-10 04:41:30'),(19,1,'Enrolled Student`s Subject','Enrolled Student Aljohns L Cagas','2024-01-10 19:59:36','2024-01-10 19:59:36'),(20,1,'Enrolled Student`s Subject','Enrolled Student James L Cagas','2024-01-11 03:24:07','2024-01-11 03:24:07');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `billings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `billings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `std_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_particulars` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_amt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `billings` WRITE;
/*!40000 ALTER TABLE `billings` DISABLE KEYS */;
INSERT INTO `billings` VALUES (1,'1','Tuition','150','2023-11-15','2023-12-15 20:59:34','2023-12-15 20:59:34'),(2,'2','Tuition','150','2023-11-15','2023-12-15 20:59:34','2023-12-15 20:59:34'),(3,'3','Tuition','150','2023-11-15','2023-12-15 20:59:34','2023-12-15 20:59:34'),(4,'4','Tuition','150','2023-11-15','2023-12-15 20:59:34','2023-12-15 20:59:34'),(5,'1','Corales, Alexander L','10000','2023-05-12','2024-01-08 22:06:50','2024-01-08 22:06:50'),(6,'1','Corales, Alexander L','10000','2023-05-12','2024-01-08 22:08:21','2024-01-08 22:08:21'),(7,'1','Jerome Lamoca','1500','2023-05-12','2024-01-08 22:09:24','2024-01-08 22:09:24'),(8,'1','aq','50','2024-02-12','2024-01-08 22:13:53','2024-01-08 22:13:53'),(9,'3','aq','50','2024-02-12','2024-01-08 22:13:53','2024-01-08 22:13:53'),(10,'5','aq','50','2024-02-12','2024-01-08 22:13:53','2024-01-08 22:13:53');
/*!40000 ALTER TABLE `billings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `Form137` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Form137_Path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Form137_Document` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSA` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSA_Path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSA_Document` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `JHS_cert` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `JHS_cert_Path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `JHS_cert_Document` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GoodMoral` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GoodMoral_Path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GoodMoral_Document` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Card` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Card_Path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Card_Document` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_student_id_foreign` (`student_id`),
  CONSTRAINT `documents_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `grade_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grade_levels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `grade_level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `grade_levels` WRITE;
/*!40000 ALTER TABLE `grade_levels` DISABLE KEYS */;
INSERT INTO `grade_levels` VALUES (1,'Grade 11',NULL,NULL),(2,'Grade 12',NULL,NULL);
/*!40000 ALTER TABLE `grade_levels` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `memos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `memo_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo_particulars` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo_amt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `memo_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `memos_student_id_foreign` (`student_id`),
  CONSTRAINT `memos_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `memos` WRITE;
/*!40000 ALTER TABLE `memos` DISABLE KEYS */;
/*!40000 ALTER TABLE `memos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2022_05_25_011756_create_tracks_table',1),(5,'2022_05_25_015849_create_strands_table',1),(6,'2022_05_25_024340_create_specializations_table',1),(7,'2022_05_25_040928_create_school_years_table',1),(8,'2022_05_25_043645_create_students_table',1),(9,'2022_05_25_045235_create_grade_levels_table',1),(10,'2022_05_25_055530_create_sems_table',1),(11,'2022_05_25_064610_create_std_spc_gl_sy_table',1),(12,'2022_05_26_155041_create_active__school_year_and_sems_table',1),(13,'2022_05_30_011133_create_billings_table',1),(14,'2022_05_31_031550_create_payments_table',1),(15,'2022_06_11_035803_create_memos_table',1),(16,'2022_06_21_030116_create_documents_table',1),(17,'2022_06_23_083457_create_permission_tables',1),(18,'2023_09_14_105556_create_subjects_table',1),(19,'2023_09_14_110550_create_student_subjects_table',1),(20,'2023_09_14_111949_create_teachers_table',1),(21,'2023_09_14_112333_create_schedules_table',1),(22,'2023_09_16_063930_create_activities_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (4,'App\\Models\\User',1),(4,'App\\Models\\User',2),(1,'App\\Models\\User',3),(2,'App\\Models\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `std_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_particulars` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_amt` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mode_of_payment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `or_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Dashboard Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(2,'Enrollment Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(3,'Student Records Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(4,'Accounting Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(5,'Reports Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(6,'Section Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(7,'Add Graduates Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(8,'System Maintenance Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(9,'Register User Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(10,'Subject Management Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(11,'Schedule Management Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(12,'View Teacher Schedule Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(13,'Teacher Management Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(14,'User Management Permission','web','2023-12-15 04:40:26','2023-12-15 04:40:26');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(5,1),(6,1),(7,1),(8,1),(10,1),(11,1),(1,2),(4,2),(1,3),(3,3),(12,3),(1,4),(2,4),(3,4),(4,4),(5,4),(6,4),(7,4),(8,4),(9,4),(10,4),(11,4),(13,4),(14,4);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Registrar','web','2023-12-15 04:40:26','2023-12-15 04:40:26'),(2,'Accounting','web','2023-12-15 04:40:27','2023-12-15 04:40:27'),(3,'Teacher','web','2023-12-15 04:40:27','2023-12-15 04:40:27'),(4,'Director','web','2023-12-15 04:40:27','2023-12-15 04:40:27'),(5,'Super Admin','web','2023-12-15 04:40:28','2023-12-15 04:40:28');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `days` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_teacher_id_foreign` (`teacher_id`),
  KEY `schedules_subject_id_foreign` (`subject_id`),
  KEY `schedules_section_id_foreign` (`section_id`),
  CONSTRAINT `schedules_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `schedules_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`),
  CONSTRAINT `schedules_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,1,32,1,'{\"0\":\"Monday\",\"3\":\"Thursday\"}','13:00:00','17:00:00','2023-12-15 15:51:44','2023-12-15 15:51:44'),(2,4,125,4,'{\"3\":\"Thursday\"}','13:00:00','17:00:00','2023-12-15 20:46:47','2023-12-15 20:46:47'),(3,1,177,5,'{\"0\":\"Monday\",\"2\":\"Wednesday\",\"4\":\"Friday\"}','13:00:00','17:00:00','2024-01-03 23:39:52','2024-01-03 23:39:52'),(4,1,2,8,'{\"1\":\"Tuesday\",\"3\":\"Thursday\"}','15:00:00','17:00:00','2024-01-07 19:02:05','2024-01-07 19:02:05');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `school_years`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `school_years` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `school_years` WRITE;
/*!40000 ALTER TABLE `school_years` DISABLE KEYS */;
INSERT INTO `school_years` VALUES (1,'2022-2023',NULL,NULL),(2,'2024-2025','2024-01-10 19:50:07','2024-01-10 19:50:07');
/*!40000 ALTER TABLE `school_years` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialization_id` bigint unsigned NOT NULL,
  `gradelevel_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sections_specialization_id_foreign` (`specialization_id`),
  KEY `sections_gradelevel_id_foreign` (`gradelevel_id`),
  CONSTRAINT `sections_gradelevel_id_foreign` FOREIGN KEY (`gradelevel_id`) REFERENCES `grade_levels` (`id`),
  CONSTRAINT `sections_specialization_id_foreign` FOREIGN KEY (`specialization_id`) REFERENCES `specializations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'A1',1,1,'2023-12-15 15:13:28','2023-12-15 15:13:28'),(2,'B1',2,1,'2023-12-15 16:52:01','2023-12-15 16:52:01'),(3,'C1',3,1,'2023-12-15 16:52:23','2023-12-15 16:52:23'),(4,'D1',4,1,'2023-12-15 16:52:44','2023-12-15 16:52:44'),(5,'E1',5,1,'2023-12-15 16:53:06','2023-12-15 16:53:06'),(6,'F1',6,1,'2023-12-15 16:53:27','2023-12-15 16:53:27'),(7,'G1',7,1,'2023-12-15 16:54:11','2023-12-15 16:54:11'),(8,'H1',8,1,'2023-12-15 16:54:54','2023-12-15 16:54:54'),(9,'100',1,2,'2023-12-15 16:55:41','2023-12-15 16:55:41'),(10,'101',2,2,'2023-12-15 16:56:02','2023-12-15 16:56:02'),(11,'102',3,2,'2023-12-15 16:56:27','2023-12-15 16:56:27'),(12,'103',4,1,'2023-12-15 16:57:06','2023-12-15 16:57:06'),(13,'103',4,2,'2023-12-15 16:57:45','2023-12-15 16:57:45'),(14,'104',5,2,'2023-12-15 16:58:06','2023-12-15 16:58:06'),(15,'105',6,2,'2023-12-15 16:58:27','2023-12-15 16:58:27'),(16,'106',7,2,'2023-12-15 16:58:48','2023-12-15 16:58:48'),(17,'107',8,2,'2023-12-15 16:59:09','2023-12-15 16:59:09');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sems` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sem` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sems` WRITE;
/*!40000 ALTER TABLE `sems` DISABLE KEYS */;
INSERT INTO `sems` VALUES (1,'1',NULL,NULL),(2,'2',NULL,NULL);
/*!40000 ALTER TABLE `sems` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `specializations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `specializations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `specialization` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `strand_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `specializations_strand_id_foreign` (`strand_id`),
  CONSTRAINT `specializations_strand_id_foreign` FOREIGN KEY (`strand_id`) REFERENCES `strands` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `specializations` WRITE;
/*!40000 ALTER TABLE `specializations` DISABLE KEYS */;
INSERT INTO `specializations` VALUES (1,'Automotive Servicing NC I',1,NULL,NULL),(2,'Electronic Products Assembly and Servicing NC II',1,NULL,NULL),(3,'Electrical Installation and Maintenance NC II',1,NULL,NULL),(4,'Housekeeping NC II',2,NULL,NULL),(5,'Front Office Service NC II',2,NULL,NULL),(6,'Food and Beverage Service NC II',2,NULL,NULL),(7,'Bread and Pastry Production NC II',2,NULL,NULL),(8,'Computer System Servicing NC II',3,NULL,NULL);
/*!40000 ALTER TABLE `specializations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `std_spc_gl_sy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `std_spc_gl_sy` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `specialization_id` bigint unsigned NOT NULL,
  `gradelevel_id` bigint unsigned NOT NULL,
  `school_year_id` bigint unsigned NOT NULL,
  `sem_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `std_spc_gl_sy_student_id_foreign` (`student_id`),
  KEY `std_spc_gl_sy_specialization_id_foreign` (`specialization_id`),
  KEY `std_spc_gl_sy_gradelevel_id_foreign` (`gradelevel_id`),
  KEY `std_spc_gl_sy_school_year_id_foreign` (`school_year_id`),
  KEY `std_spc_gl_sy_sem_id_foreign` (`sem_id`),
  KEY `std_spc_gl_sy_section_id_foreign` (`section_id`),
  CONSTRAINT `std_spc_gl_sy_gradelevel_id_foreign` FOREIGN KEY (`gradelevel_id`) REFERENCES `grade_levels` (`id`),
  CONSTRAINT `std_spc_gl_sy_school_year_id_foreign` FOREIGN KEY (`school_year_id`) REFERENCES `school_years` (`id`),
  CONSTRAINT `std_spc_gl_sy_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `std_spc_gl_sy_sem_id_foreign` FOREIGN KEY (`sem_id`) REFERENCES `sems` (`id`),
  CONSTRAINT `std_spc_gl_sy_specialization_id_foreign` FOREIGN KEY (`specialization_id`) REFERENCES `specializations` (`id`),
  CONSTRAINT `std_spc_gl_sy_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `std_spc_gl_sy` WRITE;
/*!40000 ALTER TABLE `std_spc_gl_sy` DISABLE KEYS */;
INSERT INTO `std_spc_gl_sy` VALUES (1,1,1,1,1,1,1,'2023-12-15 15:06:14','2023-12-15 16:37:03'),(2,2,4,2,1,1,NULL,'2023-12-15 16:42:11','2023-12-15 16:42:11'),(3,3,4,2,1,1,NULL,'2023-12-15 16:47:47','2023-12-15 16:47:47'),(4,4,1,1,1,1,NULL,'2023-12-15 16:50:17','2023-12-15 16:50:17'),(5,5,5,1,1,1,5,'2024-01-03 23:15:13','2024-01-03 23:38:19'),(6,6,1,1,1,1,NULL,'2024-01-05 07:09:09','2024-01-05 07:09:09'),(7,7,1,1,1,1,1,'2024-01-08 21:47:20','2024-01-08 21:49:29'),(8,8,1,2,1,2,1,'2024-01-08 22:37:14','2024-01-08 22:39:24'),(9,9,1,1,1,2,1,'2024-01-09 01:18:01','2024-01-11 16:26:58'),(10,10,1,1,1,2,1,'2024-01-09 01:33:27','2024-01-09 01:40:12'),(11,11,1,1,1,2,1,'2024-01-09 21:40:23','2024-01-09 22:25:39'),(12,12,1,1,1,2,NULL,'2024-01-10 03:53:14','2024-01-10 03:53:14'),(13,13,1,1,1,2,1,'2024-01-10 04:33:50','2024-01-10 04:38:15'),(14,14,1,1,1,2,1,'2024-01-10 19:42:03','2024-01-10 19:55:38'),(15,15,1,1,1,2,1,'2024-01-11 03:14:53','2024-01-11 03:21:27'),(16,16,1,1,1,2,NULL,'2024-01-11 08:47:51','2024-01-11 08:47:51'),(17,17,5,2,1,2,NULL,'2024-01-11 09:07:48','2024-01-11 09:07:48'),(18,18,1,2,1,2,NULL,'2024-01-16 21:26:43','2024-01-16 21:26:43');
/*!40000 ALTER TABLE `std_spc_gl_sy` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `strands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `strands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `strand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `track_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `strands_track_id_foreign` (`track_id`),
  CONSTRAINT `strands_track_id_foreign` FOREIGN KEY (`track_id`) REFERENCES `tracks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `strands` WRITE;
/*!40000 ALTER TABLE `strands` DISABLE KEYS */;
INSERT INTO `strands` VALUES (1,'(IA) Industrial Arts',1,NULL,NULL),(2,'(HE) Home Economics',1,NULL,NULL),(3,'(ICT) Information and Communication Technology',1,NULL,NULL);
/*!40000 ALTER TABLE `strands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `student_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_subjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `semester_id` bigint unsigned NOT NULL,
  `sy_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_subjects_student_id_foreign` (`student_id`),
  KEY `student_subjects_subject_id_foreign` (`subject_id`),
  KEY `student_subjects_semester_id_foreign` (`semester_id`),
  KEY `student_subjects_sy_id_foreign` (`sy_id`),
  CONSTRAINT `student_subjects_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `sems` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_subjects_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_subjects_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_subjects_sy_id_foreign` FOREIGN KEY (`sy_id`) REFERENCES `school_years` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `student_subjects` WRITE;
/*!40000 ALTER TABLE `student_subjects` DISABLE KEYS */;
INSERT INTO `student_subjects` VALUES (1,1,31,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(2,1,32,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(3,1,33,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(4,1,34,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(5,1,35,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(6,1,36,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(7,1,37,1,1,'To Enroll','2023-12-15 16:38:14','2023-12-15 16:38:14'),(8,5,174,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(9,5,175,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(10,5,176,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(11,5,177,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(12,5,178,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(13,5,179,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(14,5,180,1,1,'To Enroll','2024-01-03 23:42:02','2024-01-03 23:42:02'),(15,7,31,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(16,7,32,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(17,7,33,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(18,7,34,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(19,7,35,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(20,7,36,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(21,7,37,1,1,'To Enroll','2024-01-08 21:50:30','2024-01-08 21:50:30'),(22,10,38,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(23,10,39,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(24,10,40,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(25,10,41,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(26,10,42,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(27,10,43,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(28,10,44,2,1,'To Enroll','2024-01-09 01:42:13','2024-01-09 01:42:13'),(29,11,38,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(30,11,39,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(31,11,40,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(32,11,41,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(33,11,42,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(34,11,43,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(35,11,44,2,1,'To Enroll','2024-01-09 22:26:14','2024-01-09 22:26:14'),(36,13,38,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(37,13,39,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(38,13,40,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(39,13,41,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(40,13,42,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(41,13,43,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(42,13,44,2,1,'To Enroll','2024-01-10 04:41:30','2024-01-10 04:41:30'),(43,14,38,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(44,14,39,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(45,14,40,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(46,14,41,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(47,14,42,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(48,14,43,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(49,14,44,2,1,'To Enroll','2024-01-10 19:59:36','2024-01-10 19:59:36'),(50,15,38,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07'),(51,15,39,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07'),(52,15,40,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07'),(53,15,41,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07'),(54,15,42,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07'),(55,15,43,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07'),(56,15,44,2,1,'To Enroll','2024-01-11 03:24:07','2024-01-11 03:24:07');
/*!40000 ALTER TABLE `student_subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lrn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `std_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `civil_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `b_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `house_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purok` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brgy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `municipality` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `f_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `f_occu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `m_occu` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `relationship` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `g_contact_num` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `g_add` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prev_school` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prev_school_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jhs_yrs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_grad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gen_ave` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prim_grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prim_grade_yr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intermediate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intermediate_yr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `junior_hs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `junior_hs_yr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `enrollment_id` int NOT NULL,
  `shs_yr_graduated` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason_for_dropout` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dropout_date` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'657cdbe61d1aa.jpg','123','1234','Corales','Alexander','L','N/A','Single','19','Male','Filipino','2004-05-12','09555291377','ibaba','Phase 3','Santo Tomas','Calauan','Laguna','Alex','IT Support','Alexa','Mother','Alexa','Mother','09555291377','Calauan, Laguna','DNHS','Public','4','2017','87','80','2010','88','2014','90','2017','Regular',1,'2023-12-15 15:06:14','2023-12-15 15:06:14',1,NULL,NULL,NULL),(2,'657cf263610f6.jpg','123','1234','Monzones','Brenn','L','N/A','Single','18','Male','Filipino','2005-02-12','09555291377','ibaba','Phase 3','Santo Tomas','Calauan','Laguna','A','IT','S','IT','S','Mother','09555291377','Calauan','DNHS','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2023-12-15 16:42:11','2023-12-15 16:42:11',2,NULL,NULL,NULL),(3,'657cf3b30436b.jpg','123','123','Monzones','Vladimir','L','N/A','Single','19','Male','Filipino','2004-05-15','09555291377','ibaba','Phase 3','Santo Tomas','Calauan','Laguna','M','IT','F','IT','F','M','09555291377','Calauan','DNHS','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2023-12-15 16:47:47','2023-12-15 16:47:47',3,NULL,NULL,NULL),(4,'657cf449225a5.jpg','123','12345','Cagas','Aljohn','L','N/A','Single','19','Male','Filipino','2004-05-15','09555291377','ibaba','Phase 3','Santo Tomas','Calauan','Laguna','M','IT','F','IT','F','M','09555291377','Calauan','DNHS','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2023-12-15 16:50:17','2023-12-15 16:50:17',4,NULL,NULL,NULL),(5,'65965b0195915.jpg','1213','123','Abella','Gian','L','N/A','Single','19','Male','Filipino','2004-12-05','09555291377','Ibaba','Phase 3','Dayap','Calauan','Laguna','J','IT','M','House Wife','M','Mother','09555291377','Calauan','DNHS','Public','4','2017','90','80','2010','88','2015','90','2017','Regular',1,'2024-01-03 23:15:13','2024-01-03 23:15:13',5,NULL,NULL,NULL),(6,'65981b95d2418.jpg','123','123','Espinosa','Jay','C','N/A','Single','19','Male','Filipino','2004-05-15','09555291377','Site 3','Phase 3','Santo Tomas','Calauan','Laguna','J','IT','A','House Wife','A','Mother','09555291377','Calauan','DNHS','Public','4','2017','89','80','2010','88','2015','90','2017','Regular',1,'2024-01-05 07:09:09','2024-01-05 07:09:09',6,NULL,NULL,NULL),(7,'659cdde8aaa7e.jpg','101','191','Lamoca','Jerome','C','N/A','Single','19','Male','Filipino','2004-02-15','09555291377','site3','Phase 3','Santo Tomas','Calauan','Laguna','M','IT','F','H','F','M','09555291377','Site 3','Dayap National High School','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2024-01-08 21:47:20','2024-01-08 21:47:20',7,NULL,NULL,NULL),(8,'659ce99a59c73.jpg','101','123','Lamoca','Jerome','L','N/A','Single','19','Male','Filipino','2004-02-15','09555291377','site b3','Phase 3','San Tomas','Calauan','Laguna','M','IT','F','M','F','M','09555291377','Site 3','Dayap National High School','Public','4','2017','80','80','2010','88','2015','90','2017','Regular',3,'2024-01-08 22:37:14','2024-01-08 22:40:42',8,'2024',NULL,NULL),(9,'659d0f4999287.jpg','101','123','Credo','Jess','L','N/A','Single','19','Male','Filipino','2004-02-15','09555291377','site3','Phase 3','Dayap','Calauan','Laguna','M','IT','F','M','F','M','09555291377','site 3','DNHS','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2024-01-09 01:18:01','2024-01-09 01:18:02',9,NULL,NULL,NULL),(10,'659d12e7344bf.jpg','101','123','Cagas','Aljohn','L','N/A','Single','19','Male','Filipino','2004-02-15','09555291377','site 3','Phase 3','dayap','Calauan','Laguna','M','IT','F','H','F','M','09555291377','SITE 3','DNHS','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2024-01-09 01:33:27','2024-01-09 01:33:27',10,NULL,NULL,NULL),(11,'659e2dc78130c.jpg','101','123','Credo','Jessu','L','N/A','Single','19','Male','Filipino','2004-02-15','09555291377','phase 3','Phase 3','Dayap','Calauan','Laguna','M','IT','F','M','M','M','09555291377','Site 3','DNHS','Public','4','2017','90','80','2010','88','2015','90','2017','Regular',1,'2024-01-09 21:40:23','2024-01-09 21:40:23',11,NULL,NULL,NULL),(12,'659e852a5800a.jpg','101','123','Cagas','Vincent','L','N/A','Single','19','Male','Filipino','2004-04-15','09555291377','Ibaba','Phase 3','Dayap','Calauan','Laguna','M','IT','F','H','F','M','09555291377','Site 3','DNHS','Public','4','2017','89','80','2010','88','2014','90','2017','Regular',1,'2024-01-10 03:53:14','2024-01-10 03:53:14',12,NULL,NULL,NULL),(13,'659e8eae0bb13.jpg','123','1234','Geanga','Ian','L','N/A','Single','19','Male','Filipino','2004-03-15','09555291377','ibaba','Phase 3','Dayap','Calauan','Laguna','M','IT','F','H','F','M','09555291377','Site 3','DNHS','Public','4','2017','87','80','2010','88','2015','90','2017','Regular',1,'2024-01-10 04:33:50','2024-01-10 04:33:50',13,NULL,NULL,NULL),(14,'659f6389d065b.jpg','101','123','Cagas','Aljohns','L','N/A','Single','19','Male','Filipino','2004-02-15','09555291377','ibaba','Phase 3','Dayap','Calauan','Laguna','M','IT','F','H','F','M','09555291377','Site 3','DNHS','Public','4','2017','89','80','2010','88','2015','90','2017','Regular',1,'2024-01-10 19:42:03','2024-01-10 19:42:03',14,NULL,NULL,NULL),(15,'659fcdad472ca.jpg','101','1011','Cagas','James','L','N/A','Single','18','Male','Filipino','2005-04-15','09555291377','ibaba','Phase 3','Dayap','Calauan','Laguna','M','IT','F','H','F','M','09555291377','Site 3','DNHS','Public','4','2017','89','80','2010','88','2015','90','2017','Regular',1,'2024-01-11 03:14:53','2024-01-11 03:14:53',15,NULL,NULL,NULL),(16,'65a01bb76ac91.jpg','123','321','Credos','Jess','L','N/A','Single','19','Male','Filipino','2004-05-15','09555291377','ibaba','Phase 3','Dayap','Calauan','Laguna','M','IT','F','H','F','M','09555291377','site 3','DNHS','Public','4','2017','89','80','2010','88','2015','90','2017','Regular',1,'2024-01-11 08:47:51','2024-01-11 08:47:51',16,NULL,NULL,NULL),(17,'65a0206471cea.jpg','123','101','Bousted','Nelly','L','N/A','Single','19','Male','Filipino','2004-05-15','09555291377','ibaba','Phase 3','Dayap','Calauan','Laguna','M','IT','F','M','F','M','09555291377','Site 3','DNHS','Public','4','2017','89','80','2010','88','2015','90','2017','Regular',3,'2024-01-11 09:07:48','2024-01-11 09:08:52',17,'2024',NULL,NULL),(18,'65a7651304977.jpg','Praesentium corporis culpa aliquam amet alias re','Quisquam nemo aliquam commodi et','Lawson','Emmanuel','Tasha Doyle','Echo Gould','Single','5','Male','In obcaecati sapiente omnis velit labore voluptas','2018-07-07','Duis velit in dolor nihil totam','Adipisicing praesentium possimus distinctio Enim','Optio temporibus rerum non ea voluptas','Dolore molestias voluptatum laborum Consequatur ','Accusamus omnis elit officia voluptas et cupidita','Facilis harum eiusmod odio voluptatem dolor ad fa','Xanthus Swanson','Nostrum corporis dignissimos omnis sint officia mi','Nicholas Delgado','Placeat illo rem ipsam veniam proident sint et','Keaton Burch','Illum qui in totam iste adipisci ipsum ut nulla s','Similique soluta qui soluta sit illo et commodi co','Eligendi vitae quas autem quia quod est perspicia','Esse in occaecat eu eveniet eos lorem eum archi','Private','119','1984','Odit veniam ut aliquid est ea mollitia tempor sus','Sit debitis ex rerum deserunt reiciendis enim qui','2000','Eu ipsa quaerat veritatis dolores optio quasi pr','1990','Ut ut cum natus accusantium nostrud ipsa','1984','Regular',1,'2024-01-16 21:26:43','2024-01-16 21:26:43',18,NULL,NULL,NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialization_id` bigint unsigned NOT NULL,
  `semester_id` bigint unsigned NOT NULL,
  `grade_level_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subjects_specialization_id_foreign` (`specialization_id`),
  KEY `subjects_semester_id_foreign` (`semester_id`),
  KEY `subjects_grade_level_id_foreign` (`grade_level_id`),
  CONSTRAINT `subjects_grade_level_id_foreign` FOREIGN KEY (`grade_level_id`) REFERENCES `grade_levels` (`id`),
  CONSTRAINT `subjects_semester_id_foreign` FOREIGN KEY (`semester_id`) REFERENCES `sems` (`id`),
  CONSTRAINT `subjects_specialization_id_foreign` FOREIGN KEY (`specialization_id`) REFERENCES `specializations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (1,'101','Oral Communication',3,'Core',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(2,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(3,'103','General Mathematics',3,'Core',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(4,'104','Earth & Life Science',3,'Core',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(5,'105','Personal Development',3,'Core',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(6,'106','Physical Education 1',1,'Core',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(7,'107','Computer Systems Servicing 111 (NCI I)',5,'Applied and Specialized Subjects',8,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(8,'108','Reading and Writing',3,'Core',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(9,'109','21st Century Literature from the Philippines and the world',3,'Core',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(10,'110','Physical Education and Health 2',1,'Core',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(11,'111','Practical Research 1',3,'Core',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(12,'112','Filipino sa Piling Larangan',3,'Core',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(13,'113','Empowerment Technologies',3,'Core',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(14,'114','Computer Systems Servicing 112 (NCI II)',5,'Applied and Specialized Subjects',8,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(15,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(16,'116','Contemporary Philippine Arts from the Region',3,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(17,'117','Statistics and Probability',3,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(18,'118','Introduction to the Philiosophy of the Human Person',3,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(19,'119','Understanding Culture, Society & Politics',3,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(20,'120','Physical Education and Health 3',1,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(21,'121','Practical Research 2',3,'Core',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(22,'114','Computer Systems Servicing 121 (NCI III)',5,'Applied and Specialized Subjects',8,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(23,'123','Media & Information Literacy',3,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(24,'124','Physical Science',3,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(25,'125','Physical Education and Health 4',1,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(26,'126','English for Academic & Professional Purposes',3,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(27,'127','Entrepreneurship',3,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(28,'128','Inquiries, Investigations, & Immersion',3,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(29,'129','Work Immersion',3,'Core',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(30,'114','Computer Systems Servicing 122 (NCI II)',5,'Applied and Specialized Subjects',8,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(31,'101','Oral Communication',3,'Core',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(32,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(33,'103','General Mathematics',3,'Core',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(34,'104','Earth & Life Science',3,'Core',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(35,'105','Personal Development',3,'Core',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(36,'106','Physical Education 1',1,'Core',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(37,'107','Automotive Servicing 111 (NCI I)',5,'Applied and Specialized Subjects',1,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(38,'108','Reading and Writing',3,'Core',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(39,'109','21st Century Literature from the Philippines and the world',3,'Core',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(40,'110','Physical Education and Health 2',1,'Core',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(41,'111','Practical Research 1',3,'Core',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(42,'112','Filipino sa Piling Larangan',3,'Core',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(43,'113','Empowerment Technologies',3,'Core',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(44,'114','Automotive Servicing 112 (NCI II)',5,'Applied and Specialized Subjects',1,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(45,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(46,'116','Contemporary Philippine Arts from the Region',3,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(47,'117','Statistics and Probability',3,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(48,'118','Introduction to the Philiosophy of the Human Person',3,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(49,'119','Understanding Culture, Society & Politics',3,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(50,'120','Physical Education and Health 3',1,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(51,'121','Practical Research 2',3,'Core',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(52,'114','Automotive Servicing 121 (NCI II)',5,'Applied and Specialized Subjects',1,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(53,'123','Media & Information Literacy',3,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(54,'124','Physical Science',3,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(55,'125','Physical Education and Health 4',1,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(56,'126','English for Academic & Professional Purposes',3,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(57,'127','Entrepreneurship',3,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(58,'128','Inquiries, Investigations, & Immersion',3,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(59,'129','Work Immersion',3,'Core',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(60,'114','Automotive Servicing 122 (NCI II)',5,'Applied and Specialized Subjects',1,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(61,'101','Oral Communication',3,'Core',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(62,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(63,'103','General Mathematics',3,'Core',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(64,'104','Earth & Life Science',3,'Core',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(65,'105','Personal Development',3,'Core',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(66,'106','Physical Education 1',1,'Core',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(67,'107','Electrical Installation and Maintenance 111 (NCI I)',5,'Applied and Specialized Subjects',3,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(68,'108','Reading and Writing',3,'Core',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(69,'109','21st Century Literature from the Philippines and the world',3,'Core',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(70,'110','Physical Education and Health 2',1,'Core',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(71,'111','Practical Research 1',3,'Core',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(72,'112','Filipino sa Piling Larangan',3,'Core',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(73,'113','Empowerment Technologies',3,'Core',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(74,'114','Electrical Installation and Maintenance 112 (NCI I)',5,'Applied and Specialized Subjects',3,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(75,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(76,'116','Contemporary Philippine Arts from the Region',3,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(77,'117','Statistics and Probability',3,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(78,'118','Introduction to the Philiosophy of the Human Person',3,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(79,'119','Understanding Culture, Society & Politics',3,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(80,'120','Physical Education and Health 3',1,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(81,'121','Practical Research 2',3,'Core',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(82,'114','Electrical Installation and Maintenance 121 (NCI II)',5,'Applied and Specialized Subjects',3,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(83,'123','Media & Information Literacy',3,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(84,'124','Physical Science',3,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(85,'125','Physical Education and Health 4',1,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(86,'126','English for Academic & Professional Purposes',3,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(87,'127','Entrepreneurship',3,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(88,'128','Inquiries, Investigations, & Immersion',3,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(89,'129','Work Immersion',3,'Core',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(90,'114','Electrical Installation and Maintenance 122 (NCI II)',5,'Applied and Specialized Subjects',3,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(91,'101','Oral Communication',3,'Core',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(92,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(93,'103','General Mathematics',3,'Core',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(94,'104','Earth & Life Science',3,'Core',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(95,'105','Personal Development',3,'Core',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(96,'106','Physical Education 1',1,'Core',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(97,'107','Electronic Products Assembly and Servicing 111 (NCI I)',5,'Applied and Specialized Subjects',2,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(98,'108','Reading and Writing',3,'Core',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(99,'109','21st Century Literature from the Philippines and the world',3,'Core',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(100,'110','Physical Education and Health 2',1,'Core',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(101,'111','Practical Research 1',3,'Core',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(102,'112','Filipino sa Piling Larangan',3,'Core',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(103,'113','Empowerment Technologies',3,'Core',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(104,'114','Electronic Products Assembly and Servicing 112 (NCI I)',5,'Applied and Specialized Subjects',2,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(105,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(106,'116','Contemporary Philippine Arts from the Region',3,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(107,'117','Statistics and Probability',3,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(108,'118','Introduction to the Philiosophy of the Human Person',3,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(109,'119','Understanding Culture, Society & Politics',3,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(110,'120','Physical Education and Health 3',1,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(111,'121','Practical Research 2',3,'Core',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(112,'114','Electronic Products Assembly and Servicing 121 (NCI II)',5,'Applied and Specialized Subjects',2,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(113,'123','Media & Information Literacy',3,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(114,'124','Physical Science',3,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(115,'125','Physical Education and Health 4',1,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(116,'126','English for Academic & Professional Purposes',3,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(117,'127','Entrepreneurship',3,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(118,'128','Inquiries, Investigations, & Immersion',3,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(119,'129','Work Immersion',3,'Core',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(120,'114','Electronic Products Assembly and Servicing 122 (NCI II)',5,'Applied and Specialized Subjects',2,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(121,'101','Oral Communication',3,'Core',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(122,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(123,'103','General Mathematics',3,'Core',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(124,'104','Earth & Life Science',3,'Core',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(125,'105','Personal Development',3,'Core',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(126,'106','Physical Education 1',1,'Core',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(127,'107','Housekeeping 111 (NCI II)',5,'Applied and Specialized Subjects',4,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(128,'108','Reading and Writing',3,'Core',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(129,'109','21st Century Literature from the Philippines and the world',3,'Core',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(130,'110','Physical Education and Health 2',1,'Core',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(131,'111','Practical Research 1',3,'Core',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(132,'112','Filipino sa Piling Larangan',3,'Core',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(133,'113','Empowerment Technologies',3,'Core',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(134,'114','Front Office Service 112 (NCI II)',5,'Applied and Specialized Subjects',5,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(135,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(136,'116','Contemporary Philippine Arts from the Region',3,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(137,'117','Statistics and Probability',3,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(138,'118','Introduction to the Philiosophy of the Human Person',3,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(139,'119','Understanding Culture, Society & Politics',3,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(140,'120','Physical Education and Health 3',1,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(141,'121','Practical Research 2',3,'Core',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(142,'122','Food and Beverage Service 121 (NCI III)',5,'Applied and Specialized Subjects',6,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(143,'123','Media & Information Literacy',3,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(144,'124','Physical Science',3,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(145,'125','Physical Education and Health 4',1,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(146,'126','English for Academic & Professional Purposes',3,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(147,'127','Entrepreneurship',3,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(148,'128','Inquiries, Investigations, & Immersion',3,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(149,'129','Work Immersion',3,'Core',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(150,'130','Bread and Pastry Production 122 (NCI II)',5,'Applied and Specialized Subjects',7,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(151,'108','Reading and Writing',3,'Core',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(152,'109','21st Century Literature from the Philippines and the world',3,'Core',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(153,'110','Physical Education and Health 2',1,'Core',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(154,'111','Practical Research 1',5,'Applied and Specialized Subjects',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(155,'112','Filipino sa Piling Larangan',5,'Applied and Specialized Subjects',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(156,'113','Empowerment Technologies',5,'Applied and Specialized Subjects',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(157,'114','Front Office Services 112 (NCI II)',5,'Applied and Specialized Subjects',4,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(158,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(159,'116','Contemporary Philippine Arts from the Region',3,'Core',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(160,'117','Statistics and Probability',3,'Core',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(161,'118','Introduction to the Philiosophy of the Human Person',3,'Core',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(162,'119','Understanding Culture, Society & Politics',3,'Core',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(163,'120','Physical Education and Health 3',1,'Core',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(164,'121','Practical Research 2',5,'Applied and Specialized Subjects',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(165,'122','Food and Beverage Services (NCI III)',5,'Applied and Specialized Subjects',4,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(166,'123','Media & Information Literacy',3,'Core',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(167,'124','Physical Science',3,'Core',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(168,'125','Physical Education and Health 4',1,'Core',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(169,'126','English for Academic & Professional Purposes',5,'Applied and Specialized Subjects',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(170,'127','Entrepreneurship',5,'Applied and Specialized Subjects',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(171,'128','Inquiries, Investigations, & Immersion',5,'Applied and Specialized Subjects',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(172,'129','Bread and Pastry Production 122 (NCI III)',5,'Applied and Specialized Subjects',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(173,'130','Work Immersion',5,'Applied and Specialized Subjects',4,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(174,'101','Oral Communication',3,'Core',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(175,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(176,'103','General Mathematics',3,'Core',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(177,'104','Earth & Life Science',3,'Core',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(178,'105','Personal Development',3,'Core',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(179,'106','Physical Education 1',3,'Core',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(180,'107','Housekeeping 111 (NCI)',5,'Applied and Specialized Subjects',5,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(181,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(182,'116','Contemporary Philippine Arts from the Region',3,'Core',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(183,'117','Statistics and Probability',3,'Core',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(184,'118','Introduction to the Philiosophy of the Human Person',3,'Core',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(185,'119','Understanding Culture, Society & Politics',3,'Core',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(186,'120','Physical Education and Health 3',1,'Core',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(187,'121','Practical Research 2',5,'Applied and Specialized Subjects',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(188,'122','Food and Beverage Services (NCI III)',5,'Applied and Specialized Subjects',5,1,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(189,'123','Media & Information Literacy',3,'Core',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(190,'124','Physical Science',3,'Core',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(191,'125','Physical Education and Health 4',1,'Core',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(192,'126','English for Academic & Professional Purposes',3,'Applied and Specialized Subjects',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(193,'127','Entrepreneurship',3,'Applied and Specialized Subjects',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(194,'128','Inquiries, Investigations, & Immersion',3,'Applied and Specialized Subjects',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(195,'129','Bread and Pastry Production 122 (NCI III)',5,'Applied and Specialized Subjects',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(196,'130','Work Immersion',3,'Applied and Specialized Subjects',5,2,2,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(197,'101','Oral Communication',3,'Core',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(198,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(199,'103','General Mathematics',3,'Core',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(200,'104','Earth & Life Science',3,'Core',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(201,'105','Personal Development',3,'Core',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(202,'106','Physical Education 1',1,'Core',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(203,'107','Housekeeping 111 (NCI)',5,'Applied and Specialized Subjects',6,1,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(204,'108','Reading and Writing',3,'Core',6,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(205,'109','21st Century Literature from the Philippines and the world',3,'Core',6,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(206,'110','Physical Education and Health 2',1,'Core',6,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(207,'111','Practical Research 1',3,'Core',6,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(208,'112','Filipino sa Piling Larangan',3,'Applied and Specialized Subjects',6,2,1,'2023-12-15 04:40:29','2023-12-15 04:40:29'),(209,'113','Empowerment Technologies',3,'Applied and Specialized Subjects',6,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(210,'114','Front Office Services 112 (NCI II)',5,'Applied and Specialized Subjects',6,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(211,'123','Media & Information Literacy',3,'Core',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(212,'124','Physical Science',3,'Core',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(213,'125','Physical Education and Health 4',1,'Core',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(214,'126','English for Academic & Professional Purposes',3,'Applied and Specialized Subjects',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(215,'127','Entrepreneurship',3,'Applied and Specialized Subjects',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(216,'128','Inquiries, Investigations, & Immersion',3,'Applied and Specialized Subjects',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(217,'129','Bread and Pastry Production 122 (NCI III)',5,'Applied and Specialized Subjects',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(218,'130','Work Immersion',3,'Applied and Specialized Subjects',6,2,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(219,'101','Oral Communication',3,'Core',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(220,'102','Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',3,'Core',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(221,'103','General Mathematics',3,'Core',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(222,'104','Earth & Life Science',3,'Core',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(223,'105','Personal Development',3,'Core',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(224,'106','Physical Education 1',1,'Core',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(225,'107','Housekeeping 111 (NCI)',5,'Applied and Specialized Subjects',7,1,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(226,'108','Reading and Writing',3,'Core',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(227,'109','21st Century Literature from the Philippines and the world',3,'Core',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(228,'110','Physical Education and Health 2',1,'Core',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(229,'111','Practical Research 1',3,'Applied and Specialized Subjects',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(230,'112','Filipino sa Piling Larangan',3,'Applied and Specialized Subjects',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(231,'113','Empowerment Technologies',3,'Applied and Specialized Subjects',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(232,'114','Front Office Services 112 (NCI II)',5,'Applied and Specialized Subjects',7,2,1,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(233,'115','Pagbasa at Pagsuri ng iba\'t-ibang Teksto Tungo sa Pananaliksik',3,'Core',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(234,'116','Contemporary Philippine Arts from the Region',3,'Core',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(235,'117','Statistics and Probability',3,'Core',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(236,'118','Introduction to the Philiosophy of the Human Person',3,'Core',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(237,'119','Understanding Culture, Society & Politics',3,'Core',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(238,'120','Physical Education and Health 3',1,'Core',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(239,'121','Practical Research 2',3,'Applied and Specialized Subjects',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30'),(240,'122','Food and Beverage Services (NCI III)',5,'Applied and Specialized Subjects',7,1,2,'2023-12-15 04:40:30','2023-12-15 04:40:30');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isResigned` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teachers_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,'Alryl Kyle Mondez','Male','19','09555291377','alrylkylemondez@gmail.com',1,'2023-12-15 15:14:27','2023-12-15 15:14:52'),(3,'Ramil Kaharian','Male','19','09555291377','ramilkaharian@gmail.com',0,'2023-12-15 15:16:35','2023-12-15 15:16:35'),(4,'Alexa Smith','Female','27','09555291377','jaycababespinosa@gmail.com',0,'2023-12-15 15:17:25','2023-12-15 15:17:25'),(8,'May Abanilla','Female','27','09555291377','mayabanilla@gmail.com',0,'2023-12-15 15:19:49','2023-12-15 15:19:49'),(9,'Raden Arellano','Male','27','09555291377','radenarellano@gmail.com',0,'2024-01-04 00:22:03','2024-01-04 00:22:03');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tracks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `track` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tracks` WRITE;
/*!40000 ALTER TABLE `tracks` DISABLE KEYS */;
INSERT INTO `tracks` VALUES (1,'Tech-Voc',NULL,NULL);
/*!40000 ALTER TABLE `tracks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','admin@app.com','Admin',NULL,'$2y$10$ketCsJYjSJFs2AK0AQrUDeLpjx9WYMn3408oIBvbKpXgu0.lP9Jfi',NULL,'2023-12-15 04:40:28','2023-12-15 04:40:28'),(2,'CIT Director','capellan.spc@gmail.com','Director',NULL,'$2y$10$Ar.5mpWcD6Y.5roL76CX3.PjcmVAStHH/8znvr.Ki/zrB4T/AQccO',NULL,'2023-12-15 04:40:28','2023-12-15 04:40:28'),(3,'Registrar','registrar@registrar.com','Registrar',NULL,'$2y$10$OjaSP5/3WOAlYL2UhvPfGef9yNtu7VlCQrZLOlSKhpvjZZapb3WLW',NULL,'2023-12-15 04:40:28','2024-01-09 01:37:17'),(4,'Accounting','accounting@accounting.com','Accounting',NULL,'$2y$10$97wupj1gVp3ozTjVdxVdv.en7PySxqFhcuxIHyWWc9UOq8yayhBDm',NULL,'2023-12-15 04:40:28','2024-01-09 01:57:11');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

